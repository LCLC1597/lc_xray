import os
import shutil
from openpyxl import load_workbook
workbook = load_workbook('./b.xlsx')
sheet = workbook.active
list1 = [i.value for i in sheet[2]]


def movepic(p_name, name1):
    name2 = list1[1] + "-" + list1[2] + "-" + list1[3] + "-" + list1[4] + "-" + p_name + ".jpg"
    pos = os.path.join(r".\t", name2)
    shutil.move(pos, name1)

nub1 = 0
p_name = ""
name = r"成品{0}\{0}\{1}\{2}\{3}".format(list1[1], list1[2], list1[3], list1[4])
os.makedirs(name)
for rows in sheet.rows:
    if rows[0].value == "档号":
        continue
    name1 = os.path.join(name, rows[0].value)
    os.mkdir(name1)
    nub2 = nub1+rows[6].value
    while nub1 < nub2:
        nub1 += 1
        if nub1 < 10:
            p_name = "000"+str(nub1)
            movepic(p_name, name1)
        elif 100 > nub1 >= 10:
            p_name = "00" + str(nub1)
            movepic(p_name, name1)
        elif 1000 > nub1 >= 100:
            p_name = "0" + str(nub1)
            movepic(p_name, name1)
        elif nub1 >= 1000:
            p_name = str(nub1)
            movepic(p_name, name1)
